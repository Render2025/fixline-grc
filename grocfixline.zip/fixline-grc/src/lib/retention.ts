import type { Env } from '../types';
import { insertDeletionRecord, nowIso } from './db';

const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * Hourly cron: purge temp résumés ≤24h after processed_at.
 * Writes deletion_records only after successful R2 delete.
 * Do not claim this works in production until tested.
 */
export async function runRetentionPurge(env: Env): Promise<{ scanned: number; deleted: number }> {
  const cutoff = new Date(Date.now() - DAY_MS).toISOString();
  const rows = await env.DB.prepare(
    `SELECT id, resume_r2_key, status, processed_at FROM cases
     WHERE resume_r2_key IS NOT NULL
       AND resume_deleted_at IS NULL
       AND processed_at IS NOT NULL
       AND processed_at <= ?`,
  )
    .bind(cutoff)
    .all<{ id: string; resume_r2_key: string; status: string; processed_at: string }>();

  let deleted = 0;
  const list = rows.results ?? [];
  for (const row of list) {
    try {
      await env.RESUME_BUCKET.delete(row.resume_r2_key);
      await insertDeletionRecord(env, row.id, row.resume_r2_key, 'temp_resume', 'cron');
      await env.DB.prepare(
        `UPDATE cases SET resume_r2_key = NULL, resume_deleted_at = ?, updated_at = ? WHERE id = ?`,
      )
        .bind(nowIso(), nowIso(), row.id)
        .run();
      deleted += 1;
    } catch {
      // leave for next cron; do not write deletion_records on failure
    }
  }
  return { scanned: list.length, deleted };
}
