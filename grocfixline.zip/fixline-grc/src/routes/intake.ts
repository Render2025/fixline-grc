import type { Env, HoursPerWeek, IntakeFields, UsageContext } from '../types';
import { insertCase, recordMetric } from '../lib/db';
import { badRequest, json } from '../lib/http';
import { checkAndRecordRateLimit } from '../lib/rate-limit';
import { putObject, tempResumeKey } from '../lib/r2';
import { mintAccessToken } from '../lib/tokens';
import { ExtractError, extractResumeText } from '../pipeline/extract';

const HOURS: HoursPerWeek[] = ['lt5', '5-10', '10-20', '20plus'];
const USAGE: UsageContext[] = ['self', 'advisor'];
const MAX_BYTES = 8 * 1024 * 1024;

export async function handleIntake(request: Request, env: Env): Promise<Response> {
  if (request.method !== 'POST') return badRequest('Method not allowed', 405);

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return badRequest('Expected multipart form data');
  }

  const college = String(form.get('college') || '').trim();
  const current_goal = String(form.get('current_goal') || '').trim();
  const work_location = String(form.get('work_location') || '').trim();
  const hours_per_week = String(form.get('hours_per_week') || '').trim() as HoursPerWeek;
  const constraints = String(form.get('constraints') || '').trim();
  const usage_context = String(form.get('usage_context') || '').trim() as UsageContext;
  const resumeEntry = form.get('resume');

  if (college !== 'Green River College') {
    return badRequest('This intake endpoint is only for the Green River College pilot.');
  }
  if (!current_goal || current_goal.length < 5) return badRequest('Please describe what you are hoping to figure out.');
  if (!work_location) return badRequest('Please provide a work location / area.');
  if (!HOURS.includes(hours_per_week)) return badRequest('Invalid hours_per_week value.');
  if (!USAGE.includes(usage_context)) return badRequest('Invalid usage_context value.');
  if (resumeEntry == null || typeof resumeEntry === 'string') {
    return badRequest('Résumé file is required.');
  }
  const file = resumeEntry as unknown as {
    name: string;
    type: string;
    size: number;
    arrayBuffer(): Promise<ArrayBuffer>;
  };
  if (file.size <= 0 || file.size > MAX_BYTES) {
    return badRequest('Résumé file must be between 1 byte and 8 MB.');
  }

  const filename = file.name || 'resume.bin';
  const contentType = file.type || 'application/octet-stream';
  const bytes = await file.arrayBuffer();

  // Extract early for rate-limit fingerprint (never log body)
  let resumeText: string;
  try {
    resumeText = await extractResumeText(bytes, filename, contentType);
  } catch (err) {
    const message =
      err instanceof ExtractError
        ? err.message
        : 'Could not read that résumé format. Please upload PDF or TXT for the beta.';
    return json({ message }, 400);
  }
  if (resumeText.length < 40) {
    return json({ message: 'That résumé appears too short to analyze. Please upload a fuller PDF or TXT.' }, 400);
  }

  const caseId = crypto.randomUUID();
  const rate = await checkAndRecordRateLimit(env, resumeText, college, caseId);
  if (!rate.ok) {
    return json({ message: rate.message }, 429);
  }

  const { token, hash } = await mintAccessToken();
  const r2Key = tempResumeKey(caseId, filename);
  await putObject(env, r2Key, bytes, contentType);

  const intake: IntakeFields = {
    college,
    current_goal,
    work_location,
    hours_per_week,
    constraints,
    usage_context,
  };

  await insertCase(env, {
    id: caseId,
    intake,
    accessTokenHash: hash,
    resumeR2Key: r2Key,
    resumeFilename: filename,
    resumeContentType: contentType,
    rateLimitFingerprint: rate.fingerprint,
  });

  await env.GENERATE_QUEUE.send({
    caseId,
    attemptNumber: 1,
    reason: 'initial',
  });

  await recordMetric(env, 'intake_accepted', caseId, usage_context, {
    hours_per_week,
  });

  const base = (env.PUBLIC_BASE_URL || new URL(request.url).origin).replace(/\/$/, '');
  const redirect_url = `${base}/status/${caseId}?t=${token}`;
  return json({ redirect_url });
}
