/* Local ambient Env for tsc before wrangler types. */
interface Env {
  DB: D1Database;
  RESUME_BUCKET: R2Bucket;
  GENERATE_QUEUE: Queue;
  ASSETS?: Fetcher;
  PUBLIC_BASE_URL: string;
  MAX_REVISE_ATTEMPTS: string;
  XAI_MODEL_GENERATE: string;
  XAI_MODEL_QC: string;
  XAI_API_KEY: string;
  RATE_LIMIT_SALT: string;
  REVIEW_PASSWORD: string;
}
